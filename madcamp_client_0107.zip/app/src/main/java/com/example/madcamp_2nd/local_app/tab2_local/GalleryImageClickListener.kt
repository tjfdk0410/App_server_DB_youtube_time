package com.example.madcamp_2nd.local_app.tab2_local

interface GalleryImageClickListener {
    fun onClick(position: Int)
}