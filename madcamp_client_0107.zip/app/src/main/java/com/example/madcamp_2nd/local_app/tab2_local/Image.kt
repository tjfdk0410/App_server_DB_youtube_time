package com.example.madcamp_2nd.local_app.tab2_local

import android.net.Uri

class Image(val name: String, val uri: Uri)