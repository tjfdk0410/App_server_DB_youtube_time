package com.example.madcamp_2nd.local_app.tab1_local

class Item (val userName: String, val phoneNumber: String)