package com.example.madcamp_2nd.fb_app.tab1_fb

class Item (val userName: String, val phoneNumber: String)