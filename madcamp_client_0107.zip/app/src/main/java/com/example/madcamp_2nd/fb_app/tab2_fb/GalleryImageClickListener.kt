package com.example.madcamp_2nd.fb_app.tab2_fb

interface GalleryImageClickListener {
    fun onClick(position: Int)
}