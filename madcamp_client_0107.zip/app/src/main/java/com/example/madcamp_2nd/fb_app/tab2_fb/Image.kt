package com.example.madcamp_2nd.fb_app.tab2_fb

import android.net.Uri

class Image(val name: String, val uri: Uri)