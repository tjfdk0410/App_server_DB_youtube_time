# madcamp_1st
KAIST MADCAMP 1st WEEK

### 첫 번째 탭
휴대폰에 저장된 연락처 불러오기 및 추가 기능

### 두 번째 탭
휴대폰에 저장된 사진을 불러와서 나만의 갤러리 만들기

### 세 번째 탭
휴대폰의 카메라를 이용한 실시간 Style Transfer